import { MapPin } from "lucide-react"

export default function ServiceArea() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Service Area</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            We proudly serve the greater metropolitan area and surrounding communities with reliable electrical
            services.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span className="text-gray-700">Downtown</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span className="text-gray-700">Westside</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span className="text-gray-700">Northbrook</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span className="text-gray-700">Eastside</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span className="text-gray-700">Southgate</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span className="text-gray-700">Riverside</span>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Service Radius: 25 Miles</h3>
              <p className="text-gray-600 mb-4">
                We provide electrical services within a 25-mile radius of our main office. Emergency services available
                24/7 throughout our entire service area.
              </p>
              <p className="text-sm text-gray-500">
                Not sure if we service your area? Give us a call and we'll let you know!
              </p>
            </div>
          </div>

          <div className="bg-gray-200 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center text-gray-500">
              <MapPin className="h-16 w-16 mx-auto mb-4" />
              <p className="text-lg font-medium">Interactive Service Area Map</p>
              <p className="text-sm">Map integration would be implemented here</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
