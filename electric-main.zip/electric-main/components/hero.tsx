import Image from "next/image"
import BookingForm from "@/components/booking-form"

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/placeholder.svg?height=800&width=1200&text=Professional+electrician+working+on+electrical+panel+in+modern+home"
          alt="Professional electrician working on electrical panel"
          fill
          className="object-cover"
          priority
        />
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-black/50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content - Hero Text */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Reliable Residential & Commercial <span className="text-blue-400">Electrical Services</span>
              </h1>
              <p className="text-xl text-gray-200 leading-relaxed">
                Licensed, insured, and trusted by homeowners and businesses across the region. Available 24/7 for
                emergency repairs with same-day service guarantee.
              </p>
            </div>

            {/* Key Features */}
            <div className="flex flex-wrap gap-4 text-white">
              <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                <span className="text-sm font-medium">24/7 Emergency Service</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                <span className="text-sm font-medium">Licensed & Insured</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                <span className="text-sm font-medium">Same-Day Service</span>
              </div>
            </div>
          </div>

          {/* Right Content - Booking Form */}
          <div className="lg:pl-8">
            <BookingForm />
          </div>
        </div>
      </div>
    </section>
  )
}
