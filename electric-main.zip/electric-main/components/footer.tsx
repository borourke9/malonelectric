import Link from "next/link"
import { Phone, Mail, MapPin, Clock, Zap } from "lucide-react"

export default function Footer() {
  return (
    <footer id="contact" className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="bg-blue-500 p-2 rounded-lg">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold">ElectricPro</span>
            </Link>
            <p className="text-gray-300 text-sm">
              Licensed, insured, and trusted electrical services for residential and commercial properties.
            </p>
            <div className="text-sm text-gray-400">
              <p>License #: EL-2024-12345</p>
              <p>Fully Insured & Bonded</p>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Info</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-blue-400" />
                <span>(555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-blue-400" />
                <span>info@electricpro.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-blue-400" />
                <span>123 Main St, Your City, ST 12345</span>
              </div>
            </div>
          </div>

          {/* Business Hours */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Business Hours</h3>
            <div className="space-y-2 text-sm text-gray-300">
              <div className="flex justify-between">
                <span>Monday - Friday:</span>
                <span>7:00 AM - 6:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Saturday:</span>
                <span>8:00 AM - 4:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Sunday:</span>
                <span>Emergency Only</span>
              </div>
              <div className="flex items-center space-x-2 pt-2 border-t border-gray-700">
                <Clock className="h-4 w-4 text-blue-400" />
                <span className="text-blue-400 font-medium">24/7 Emergency Service</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <div className="space-y-2 text-sm">
              <Link href="#services" className="block text-gray-300 hover:text-blue-400 transition-colors">
                Our Services
              </Link>
              <Link href="#about" className="block text-gray-300 hover:text-blue-400 transition-colors">
                About Us
              </Link>
              <Link href="#contact" className="block text-gray-300 hover:text-blue-400 transition-colors">
                Contact
              </Link>
              <Link href="/emergency" className="block text-gray-300 hover:text-blue-400 transition-colors">
                Emergency Service
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 ElectricPro. All rights reserved. | Licensed Electrical Contractor</p>
        </div>
      </div>
    </footer>
  )
}
